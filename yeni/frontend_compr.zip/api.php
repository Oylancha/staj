<?php
// Root API entry point proxying to backend_php/api.php
require_once __DIR__ . '/backend_php/api.php';
